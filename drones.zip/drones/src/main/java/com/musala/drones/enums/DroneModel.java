package com.musala.drones.enums;

public enum DroneModel {

    Lightweight, Middleweight, Cruiserweight, Heavyweight;
}
