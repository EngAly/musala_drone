package com.musala.drones.enums;

public enum DroneLoadStatus {

    LOADED, DELIVERED;
}
