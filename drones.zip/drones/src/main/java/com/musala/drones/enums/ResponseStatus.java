package com.musala.drones.enums;

public enum ResponseStatus {

    Success, Fail,
}
